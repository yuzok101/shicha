# Tavlin source and release notes

The v56 release was deployed to the existing `tavlin` Cloudflare Worker on 2026-09-28 (version `3445edb3-02ab-47c1-87b5-bf1928efd445`). The `SPEC-COVERAGE.md` table maps the original 129 requirements to the pre-release baseline and is not an up-to-date completion claim. The next change, v57, makes Cooking Mode screen wake lock automatic while open, releases it on exit, and shows an honest fallback when unsupported.

The deploy layout is `public/` plus `worker.js` and `wrangler.toml`. The small candidate-source ZIP on the isolated GitHub branch does not contain model/runtime binaries. The original five-part deployment tar DOES contain `public/htr/` model/runtime binaries and `public/ocr/` assets. The v3 five-part deployment tar and its manifest are on this branch. Reassemble parts in numeric suffix order and verify each part and the tar against the matching manifest. New source changes after v3 must be packaged and backed up before production deployment.

Mishkefet-v1 by itayinbar, CC BY-NC-SA 4.0, non-commercial only: https://huggingface.co/itayinbar/Mishkefet-v1. See `htr/LICENSE-MODEL.txt`.

Handwriting quality gate: automatic draft text is shown only when model confidence, Hebrew content, and recipe-specific cues all pass. This deliberately rejects ordinary handwritten prose and may reject valid recipe pages; the image remains available for manual transcription. A small benchmark with actual handwritten recipes and known transcription is still needed to tune the gate.

Test status (2026-09-28): local Chrome confirmed three non-recipe handwritten benchmark pages and four blank/degraded pages fail closed, and a synthetic typed recipe is rejected. This does not prove actual handwritten recipes pass. A mocked-API browser flow confirmed editable scan review before the explicit save, one POST on save, one DELETE on editor delete, and PUT restore on undo. A failed POST leaves a local draft and no claimed account save. Wrangler dry-run passed; no production deployment.

Release check (2026-09-28): two authentic handwritten Hebrew recipe images (a lined "פרפה מוקה" note and an aged yeast-cake note) produced garbled words/quantities and were rejected by the gate. Therefore HTR is NOT validated as practically usable. It is deployed only as opt-in, fail-closed experimental recognition. Do not describe it as a working handwriting recognizer. The manual scan-entry route is the safe fallback.

Release note
v57: automatic Cooking Mode Wake Lock request and release on dialog close/pagehide; visible fallback on unsupported/denied devices. Local mocked Chrome test exercised two acquire/release cycles, including completion. Browser support/device behavior still requires a real tablet test.
