# Tavlin source and release notes

The v56 release was deployed to the existing `tavlin` Cloudflare Worker on 2026-09-28 (version `3445edb3-02ab-47c1-87b5-bf1928efd445`). The `SPEC-COVERAGE.md` table maps the original 129 requirements to the pre-release baseline and is not an up-to-date completion claim. The next change, v57, makes Cooking Mode screen wake lock automatic while open, releases it on exit, and shows an honest fallback when unsupported.

The deploy layout is `public/` plus `worker.js` and `wrangler.toml`. The small candidate-source ZIP on the isolated GitHub branch does not contain model/runtime binaries. The original five-part deployment tar DOES contain `public/htr/` model/runtime binaries and `public/ocr/` assets. The v3 five-part deployment tar and its manifest are on this branch. Reassemble parts in numeric suffix order and verify each part and the tar against the matching manifest. New source changes after v3 must be packaged and backed up before production deployment.

Mishkefet-v1 by itayinbar, CC BY-NC-SA 4.0, non-commercial only: https://huggingface.co/itayinbar/Mishkefet-v1. See `htr/LICENSE-MODEL.txt`.

Handwriting quality gate: automatic draft text is shown only when model confidence, Hebrew content, and recipe-specific cues all pass. This deliberately rejects ordinary handwritten prose and may reject valid recipe pages; the image remains available for manual transcription. A small benchmark with actual handwritten recipes and known transcription is still needed to tune the gate.

Test status (2026-09-28): local Chrome confirmed three non-recipe handwritten benchmark pages and four blank/degraded pages fail closed, and a synthetic typed recipe is rejected. This does not prove actual handwritten recipes pass. A mocked-API browser flow confirmed editable scan review before the explicit save, one POST on save, one DELETE on editor delete, and PUT restore on undo. A failed POST leaves a local draft and no claimed account save. Wrangler dry-run passed; no production deployment.

Release check (2026-09-28): two authentic handwritten Hebrew recipe images (a lined "פרפה מוקה" note and an aged yeast-cake note) produced garbled words/quantities and were rejected by the gate. Therefore HTR is NOT validated as practically usable. It is deployed only as opt-in, fail-closed experimental recognition. Do not describe it as a working handwriting recognizer. The manual scan-entry route is the safe fallback.

Release note
v57: automatic Cooking Mode Wake Lock request and release on dialog close/pagehide; visible fallback on unsupported/denied devices. Local mocked Chrome test exercised two acquire/release cycles, including completion. Browser support/device behavior still requires a real tablet test.

v58 candidate: optional per-recipe completed cooking history in the recipe menu. Reads only user-owned completed sessions (joins each recipe on owner, excludes trashed recipes); date/time shown in Hebrew. No notes, ratings or media are claimed. Mocked Chrome test covers the menu, filtering, and close; SQLite query checked against predeploy schema.

v58.1 correction: the service-worker precache must request the same `3-app.js?v=58` that the homepage loads. Otherwise a new offline install might cache the prior version; fixed and locally retested before follow-up deploy.

v59 candidate: read-only recipe version list and preview from existing `recipe_versions` snapshots, scoped to the authenticated owner and an active recipe. Snapshot count is capped at 100; `partial=true` warns callers when there may be older snapshots beyond the cap. Version numbers are display-order values within that cap, not a persistent version_number column. Restore and diff are explicitly not implemented. Chrome mock covered two versions and read-only preview; screenshot inspected.

v59.1 live fix: authenticated production showed current recipe ingredients/steps as JSON strings in the version endpoint, so the preview crashed. Decode those fields to arrays in the endpoint; the actual historic snapshots also have serialized strings. Normalize both current and historic ingredients/steps to arrays, with a test using D1-shaped strings.

v60 release: conservative duplicate warning for new recipes. Exact normalized title or strong three-ingredient overlap against already loaded recipes raises a review dialog. The user can open the existing recipe, return to the unsaved editor, or explicitly save anyway. Does not silently merge or overwrite and does not claim exhaustive fuzzy detection. Local Chrome confirms cancel leaves editor and no POST; save-anyway makes one POST.

v61 candidate: forgiving Hebrew search across names, categories, notes, ingredients and steps (normalization, partial words, one typo and common missing ו/י); multi-recipe selection to add unique *exact* ingredient lines to the shopping list, without pretending to sum quantities; clean print view with the browser's print-to-PDF option. No favorite screen or account-level favorite sync is claimed. Local Chrome tests cover typo search, multi-selection, exact-line dedupe and print HTML.


v62 candidate: owner-scoped persistent favorite toggle/filter with a D1 table created lazily on first request, plus a truthful server-sourced recipe backup. The backup is limited to recipe text/metadata; photos, scans, versions, cooking history and settings are excluded and the UI says so. Local browser test covers favorite PUT/filter/DELETE and backup download.

v63 candidate: backup import validation and preview before any write. Shows new versus existing IDs and names; defaults to new-only. Overwriting existing recipes requires a separate checkbox and confirmation; successful updates use the ordinary recipe endpoint so versions are made. Stops on first failed write and reports partial progress. The backup remains recipe text/metadata only, not a full multimedia/history backup. Local Chrome covers cancel, default, explicit overwrite and invalid-file rejection.

v63.1 candidate: expose backup-file input as a visible control on the backup page, so the preview is accessible and testable from the browser. Keeps the same no-write-before-confirm and new-only default.

v64 candidate: restore a historical recipe version from the read-only preview after a browser confirmation. The endpoint checks owner, active recipe and version ownership; it saves the outgoing current recipe as a snapshot in the same D1 batch, then replaces only recipe text fields. It refuses a no-op restore. Browser mock tests cover cancel with zero POST and confirmed restore with one POST and updated view. Production restore should only be tested against a disposable test recipe, never a family recipe.

v65 candidate: multi-recipe shopping preview before any server write. Conservative arithmetic only for unitless numeric onions, tomatoes and potatoes; unsupported units remain their original text, identical lines deduplicate. The preview states the limits and requires explicit confirmation. Local Chrome covered 2+1+3 onions = 6, exact-line dedupe, cancel with zero POST, and confirmed three item POSTs. This is a partial clause 48, not a general unit engine.

v66 candidate: optional basic account-scoped inventory with pantry/fridge/freezer, quantity, unit, date, optional expiry and note. Add/list/delete only. It does not yet subtract items from shopping or match inventory to recipes. Local Chrome tests add/read/delete and Wrangler dry-run. The table is created lazily on first inventory request.

v68 candidate (not yet deployed): owner-requested barcode scan-in and scan-out. Original WhatsApp requests: 2026-09-28 18:45 (wamid.HBgMOTcyNTMyNDkwMzUxFQIAEhgUM0FFRDUyNEU5REVCQTk5RjdGRkIA), 18:46 (wamid.HBgMOTcyNTMyNDkwMzUxFQIAEhgUM0E5QTZDMDBCNTk3M0M2OEE2NTAA). Browser BarcodeDetector/getUserMedia where supported, manual number/name fallback, free Open Food Facts lookup, reviewed inbound inventory addition, outbound transactional decrement + shopping item, zero stock retained, absent stock shopping-only. Browser compatibility and live backend behavior remain to verify. No mandatory paid service.
