Tavlin v60 source and changed public assets. Apply over v59.2 full source archive in same GitHub branch. Large unchanged HTR assets are in that base archive.
