// בודק את פונקציות האיחוד מתוך worker.js (מחלץ את הבלוק המסומן ובודק אותו בפועל)
import {readFileSync} from 'fs';
const src=readFileSync(process.argv[2]||'/home/hatch/workspace/tavlin/work/worker.js','utf8');
const m=src.match(/\/\/ ==SHOP-MERGE-START==([\s\S]*?)\/\/ ==SHOP-MERGE-END==/);
if(!m){console.error('merge block not found');process.exit(1)}
eval(m[1]+';globalThis.__shop={shopNorm,shopParseQty,shopMergeKey,shopMergeTexts};');
const {shopNorm,shopParseQty,shopMergeKey,shopMergeTexts}=globalThis.__shop;
let pass=0,fail=0;
const eq=(name,got,want)=>{const ok=got===want;ok?pass++:fail++;console.log(ok?'✓':'✗',name,ok?'':`→ got ${JSON.stringify(got)}, want ${JSON.stringify(want)}`)};
eq('exact dup',shopMergeTexts('חלב','חלב'),'חלב');
eq('exact dup whitespace',shopMergeTexts('  חלב  ','חלב'),'חלב');
eq('qty same unit singular/plural',shopMergeTexts('2 כוסות קמח','1 כוס קמח'),'3 כוסות קמח');
eq('qty sum to one',shopMergeTexts('1 כפית מלח','0'),null); // sanity: invalid
eq('qty tbsp',shopMergeTexts('2 כפות שמן','1 כף שמן'),'3 כפות שמן');
eq('qty no unit',shopMergeTexts('2 ביצים','3 ביצים'),'5 ביצים');
eq('qty grams',shopMergeTexts('500 גרם קמח','500 גרם קמח'),'1000 גרם קמח');
eq('fraction',shopMergeTexts('1/2 כוס סוכר','1/2 כוס סוכר'),'1 כוס סוכר');
eq('mixed fraction',shopMergeTexts('1 1/2 כוסות חלב','1/2 כוס חלב'),'2 כוסות חלב');
eq('decimal',shopMergeTexts('0.5 קג קמח','0.5 קג קמח'),'1 ק"ג קמח');
eq('different items',shopMergeTexts('2 כוסות קמח','1 כוס סוכר'),null);
eq('qty vs no-qty',shopMergeTexts('מלח','1 כפית מלח'),null);
eq('no-qty dup',shopMergeTexts('מלח','מלח'),'מלח');
eq('key norm',shopMergeKey('2 כוסות קמח'),'כוס קמח');
eq('key no-qty',shopMergeKey('מלח'),'מלח');
eq('parse ml',shopParseQty('250 מל חלב').unit,'מ"ל');
eq('parse no qty',shopParseQty('מלח').qty,null);
console.log(`\n${pass} עברו, ${fail} נכשלו`);
process.exit(fail?1:0);
