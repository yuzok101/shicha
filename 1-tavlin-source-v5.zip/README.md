# Tavlin HTR integration candidate (not deployed)

This folder is an implementation candidate based on the live production JS fetched 2026-09-28; no production deploy has occurred. `SPEC-COVERAGE.md` maps the original 129 requirements to the observed live baseline, not to this candidate.

The deploy layout is `public/` plus `worker.js` and `wrangler.toml`. The small candidate-source ZIP on the isolated GitHub branch does not contain model/runtime binaries. The original five-part deployment tar DOES contain `public/htr/` model/runtime binaries and `public/ocr/` assets. The revised v2 five-part deployment tar has its own `tavlin-candidate-v2-MANIFEST.txt` and is not yet uploaded; the older tar in GitHub lacks the latest fixes. Reassemble each version in numeric suffix order and verify every part and tar against its own manifest before use. Neither candidate is deployed, and tests must pass before any production change.

Mishkefet-v1 by itayinbar, CC BY-NC-SA 4.0, non-commercial only: https://huggingface.co/itayinbar/Mishkefet-v1. See `htr/LICENSE-MODEL.txt`.

Handwriting quality gate: automatic draft text is shown only when model confidence, Hebrew content, and recipe-specific cues all pass. This deliberately rejects ordinary handwritten prose and may reject valid recipe pages; the image remains available for manual transcription. A small benchmark with actual handwritten recipes and known transcription is still needed to tune the gate.

Test status (2026-09-28): local Chrome confirmed three non-recipe handwritten benchmark pages and four blank/degraded pages fail closed, and a synthetic typed recipe is rejected. This does not prove actual handwritten recipes pass. A mocked-API browser flow confirmed editable scan review before the explicit save, one POST on save, one DELETE on editor delete, and PUT restore on undo. A failed POST leaves a local draft and no claimed account save. Wrangler dry-run passed; no production deployment.

Release check (2026-09-28): two authentic handwritten Hebrew recipe images (a lined "פרפה מוקה" note and an aged yeast-cake note) produced garbled words/quantities and were rejected by the gate. Therefore HTR is NOT validated as practically usable. Do not deploy it as a working recognition feature. The manual scan-entry route is the safe fallback.
