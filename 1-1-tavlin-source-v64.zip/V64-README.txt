Tavlin v64 source and changed public assets. Apply over v59.2 full-source archive in same GitHub branch. Large unchanged OCR and HTR assets remain in that base archive.
