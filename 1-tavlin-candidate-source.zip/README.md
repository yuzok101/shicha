# Tavlin HTR integration candidate (not deployed)

This folder is an implementation candidate based on the live production JS fetched 2026-09-28; no production deploy has occurred. `SPEC-COVERAGE.md` maps the original 129 requirements to the observed live baseline, not to this candidate.

The deploy layout is `public/` plus `worker.js` and `wrangler.toml`. The source archive does not contain model/runtime binaries because GitHub's browser upload limit prevents an 85MB archive. Model assets are currently hosted only at the separate test Worker and must be copied locally into `public/htr/` before deploying. No production deployment should occur from an incomplete archive.

Mishkefet-v1 by itayinbar, CC BY-NC-SA 4.0, non-commercial only: https://huggingface.co/itayinbar/Mishkefet-v1. See `htr/LICENSE-MODEL.txt`.
